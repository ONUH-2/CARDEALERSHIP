<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/cars.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inventory | Akaza's Motors</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        :root {
            --bg: #f5f9ff;
            --surface: #ffffff;
            --surface-alt: #f1f7ff;
            --text: #111827;
            --muted: #475569;
            --border: #dbe7ff;
            --accent: #2563eb;
            --accent-dark: #1d4ed8;
            --shadow: 0 18px 45px rgba(37, 99, 235, 0.12);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        html { scroll-behavior: smooth; }

        body {
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            background: var(--bg);
            color: var(--text);
            overflow-x: hidden;
        }

        ::-webkit-scrollbar { width: 10px; }
        ::-webkit-scrollbar-track { background: var(--surface-alt); }
        ::-webkit-scrollbar-thumb { background: #9fb9eb; }
        ::-webkit-scrollbar-thumb:hover { background: var(--accent); }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(18px);
            z-index: 1000;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
        }

        .logo {
            font-size: 30px;
            font-weight: 700;
            letter-spacing: 2px;
            color: var(--text);
            cursor: pointer;
        }

        .nav-links { display: flex; list-style: none; flex-wrap: wrap; gap: 24px; }

        .nav-links a {
            text-decoration: none;
            color: var(--text);
            font-weight: 500;
            transition: color 0.25s ease;
            position: relative;
        }

        .nav-links a:hover { color: var(--accent); }

        .nav-links a::after {
            content: "";
            position: absolute;
            width: 0;
            height: 2px;
            background: var(--accent);
            left: 0;
            bottom: -8px;
            transition: width 0.25s ease;
        }

        .nav-links a:hover::after { width: 100%; }

        .user-area {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .user-name {
            color: var(--text);
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .user-logout {
            color: var(--accent);
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .nav-cta {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 18px;
            border-radius: 999px;
            background: var(--accent);
            color: #fff;
            font-weight: 700;
            text-decoration: none;
        }

        .nav-cta:hover {
            background: var(--accent-dark);
        }

        .hero {
            min-height: 88vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            position: relative;
            padding: 120px 24px 80px;
            background: linear-gradient(90deg, rgba(245, 249, 255, 0.95) 0%, rgba(241, 247, 255, 0.85) 100%), url('images/begin.jpg') center/cover no-repeat;
        }

        .overlay {
            display: none;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 860px;
            padding: 0 24px;
        }

        .hero-content h1 {
            font-size: clamp(3.5rem, 6vw, 5.8rem);
            font-weight: 700;
            line-height: 1.02;
            margin-bottom: 20px;
            color: var(--text);
        }

        .hero-content h1 span { display: block; color: var(--accent); }

        .hero-content p {
            font-size: 1.13rem;
            color: var(--muted);
            margin-top: 18px;
            line-height: 1.8;
        }

        .inventory {
            padding: 120px 8%;
            background: var(--surface);
            max-width: 1550px;
            margin: 0 auto;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .title {
            max-width: 850px;
            margin: 0 auto 40px;
            text-align: center;
        }

        .title h2 {
            font-size: clamp(2.5rem, 3vw, 3.2rem);
            margin-bottom: 16px;
            color: var(--text);
        }

        .title p { color: var(--muted); font-size: 1rem; line-height: 1.8; }

        .car-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 36px;
            align-items: stretch;
        }

        .car-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 28px;
            overflow: hidden;
            transition: transform 0.35s ease, box-shadow 0.35s ease, opacity 0.7s ease;
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            min-height: 520px;
            opacity: 0;
            transform: translateY(24px);
        }

        .car-card.reveal {
            opacity: 1;
            transform: translateY(0);
        }

        .car-card:hover {
            transform: translateY(-6px);
            border-color: rgba(37, 99, 235, 0.28);
            box-shadow: 0 28px 72px rgba(37, 99, 235, 0.16);
        }

        .car-image {
            width: 100%;
            aspect-ratio: 16 / 9;
            min-height: 280px;
            overflow: hidden;
            background: var(--surface-alt);
        }

        .car-image img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            display: block;
            transition: transform 0.4s ease;
        }

        .car-card:hover .car-image img { transform: scale(1.02); }

        .car-info {
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 16px;
            flex: 1;
        }

        .car-title-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 18px;
        }

        .car-title-row h3 {
            font-size: 24px;
            line-height: 1.15;
            margin-bottom: 0;
            color: var(--text);
        }

        .price-pill {
            background: var(--surface-alt);
            color: var(--accent);
            padding: 10px 16px;
            border-radius: 999px;
            font-size: 0.95rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .car-tagline { color: var(--muted); line-height: 1.75; font-size: 1rem; min-height: 52px; }

        .car-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            color: var(--muted);
            font-size: 0.95rem;
        }

        .car-meta span {
            padding: 8px 14px;
            background: var(--surface-alt);
            border-radius: 999px;
            border: 1px solid var(--border);
        }

        .btn-full { margin-top: auto; }

        .car-info .btn-white {
            width: 100%;
            padding: 16px 18px;
            min-height: 54px;
            display: inline-flex;
            justify-content: center;
            border-radius: 999px;
            font-weight: 700;
            background: var(--accent);
            color: #fff;
            transition: transform 0.22s ease, background 0.22s ease;
            border: 0;
            text-decoration: none;
        }

        .car-info .btn-white:hover {
            background: var(--accent-dark);
            transform: translateY(-1px);
        }

        .why-us {
            padding: 80px 8% 120px;
            background: linear-gradient(180deg, #f9fcff 0%, #f4f9ff 100%);
        }

        .why-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 24px;
            margin-top: 32px;
        }

        .why-box {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 28px;
            box-shadow: var(--shadow);
        }

        .why-box h3 { margin-bottom: 14px; font-size: 1.3rem; color: var(--text); }
        .why-box p { color: var(--muted); line-height: 1.8; }

        footer { padding: 60px 8%; background: #f4f8ff; }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 28px;
            margin-bottom: 24px;
        }

        .footer-section h3 { font-size: 1.05rem; margin-bottom: 16px; color: var(--text); }

        .footer-section p,
        .footer-section a {
            color: var(--muted);
            display: block;
            margin-bottom: 10px;
            text-decoration: none;
            font-size: 0.95rem;
        }

        .footer-section a:hover { color: var(--accent); }
        footer hr { border-color: var(--border); margin-bottom: 24px; }

        @media (max-width: 992px) { .hero-content h1 { font-size: 4.5rem; } }

        @media (max-width: 768px) {
            .navbar { flex-direction: column; padding: 20px; }
            .nav-links { justify-content: center; margin-top: 16px; }
            .hero { height: auto; min-height: 70vh; padding-top: 100px; }
            .hero-content h1 { font-size: 3rem; }
            .inventory { padding: 90px 5%; }
        }

        @media (max-width: 640px) {
            .car-grid { grid-template-columns: 1fr; }
            .car-image { min-height: 220px; }
            .car-title-row { flex-direction: column; align-items: flex-start; }
            .car-title-row h3 { font-size: 20px; }
        }
    </style>

</head>

<body>

    <nav class="navbar">

        <div class="logo">

            AKAZA'S MOTORS

        </div>

        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="inventory.php">Inventory</a></li>
            <li><a href="index.php#about">About</a></li>
            <li><a href="index.php#services">Services</a></li>
            <li><a href="index.php#reviews">Reviews</a></li>
            <li><a href="index.php#contact">Contact</a></li>
            <?php if (is_logged_in()): ?>
                <li><a href="my-orders.php">My Orders<?php $navCount = get_nav_order_count(); if ($navCount > 0): ?> <span style="display:inline-flex;min-width:18px;height:18px;padding:0 5px;align-items:center;justify-content:center;border-radius:999px;background:var(--accent);color:#fff;font-size:0.7rem;margin-left:4px;vertical-align:middle;"><?php echo $navCount; ?></span><?php endif; ?></a></li>
            <?php endif; ?>
            <?php if (is_admin_user()): ?>
                <li><a href="admin/dashboard.php">Admin</a></li>
            <?php endif; ?>
        </ul>

        <?php if (!empty($_SESSION['username'])): ?>
            <div class="user-area">
                <span class="user-name"><i class="fa fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a class="user-logout" href="login/logout.php"><i class="fa fa-sign-out-alt"></i> Log out</a>
            </div>
        <?php else: ?>
            <a class="nav-cta" href="login/login.php?form=signup"><i class="fa fa-user-plus"></i> Sign Up</a>
        <?php endif; ?>

    </nav>

    <section class="hero" id="home">

        <div class="overlay"></div>

        <div class="hero-content">

            <h1>

                OUR COMPLETE

                <span>INVENTORY</span>

            </h1>

            <p>

                Browse our full collection of luxury vehicles.

                Find your perfect match today.

            </p>

        </div>

    </section>

    
    <section class="inventory" id="inventory">

        <div class="title">

            <h2>All Available Vehicles</h2>

            <p>

                Discover our complete collection of premium luxury vehicles.

            </p>

        </div>

        <div class="car-grid">

            <?php
            $cars = get_all_cars();
            foreach ($cars as $car):
                $image = first_car_image($car);
            ?>
                <article class="car-card">
                    <div class="car-image">
                        <img src="<?php echo htmlspecialchars(car_image_url($image)); ?>" alt="<?php echo htmlspecialchars($car['name']); ?>">
                    </div>
                    <div class="car-info">
                        <div class="car-title-row">
                            <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                            <span class="price-pill"><?php echo htmlspecialchars($car['price']); ?></span>
                        </div>
                        <p class="car-tagline"><?php echo htmlspecialchars($car['tagline']); ?></p>
                        <div class="car-meta">
                            <span><?php echo htmlspecialchars($car['year']); ?></span>
                            <span><?php echo htmlspecialchars($car['mileage']); ?></span>
                            <span><?php echo htmlspecialchars($car['drivetrain']); ?></span>
                        </div>
                        <div class="car-actions" style="margin-top:14px;">
                            <a class="btn-white btn-full" href="car-details.php?id=<?php echo (int)$car['id']; ?>">View Details</a>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>

        </div>

    </section>

    <section class="why-us">

        <div class="title">

            <h2>Interested in a Vehicle?</h2>

            <p>

                Contact us today to schedule a test drive.

            </p>

        </div>

        <div class="why-grid">

            <div class="why-box">

                <h3>Flexible Financing</h3>

                <p>Affordable payment plans designed for you.</p>

            </div>

            <div class="why-box">

                <h3>Test Drive</h3>

                <p>Experience luxury before you buy.</p>

            </div>

            <div class="why-box">

                <h3>Trade-In Service</h3>

                <p>Get the best value for your current vehicle.</p>

            </div>

            <div class="why-box">

                <h3>Expert Support</h3>

                <p>Our team is here to assist you anytime.</p>

            </div>

        </div>

    </section>

    
    <script>
        const inventoryCards = document.querySelectorAll('.car-card');
        const inventoryObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('reveal');
                    inventoryObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        inventoryCards.forEach((card) => inventoryObserver.observe(card));
    </script>

    <footer>

        <div class="footer-content">

            <div class="footer-section">

                <h3>AKAZA'S MOTORS</h3>

                <p>Luxury. Performance. Excellence.</p>

            </div>

            <div class="footer-section">

                <h3>Quick Links</h3>

                <a href="index.php#home">Home</a>

                <a href="inventory.php">Inventory</a>

                <a href="index.php#about">About</a>

                <a href="index.php#services">Services</a>

                <a href="index.php#contact">Contact</a>

            </div>

            <div class="footer-section">

                <h3>Contact</h3>

                <p>Lagos, Nigeria</p>

                <p>+234 000 000 0000</p>

                <p>info@akazasmotors.com</p>

            </div>

        </div>

        <hr>

        <p style="text-align: center; padding: 20px 0;">© 2026 Akaza's Motors. All Rights Reserved.</p>

    </footer>

</body>

</html>
