<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/../form/inc/connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Akaza's Motors | Luxury Car Dealership</title>

    <style>
        :root {
            color-scheme: light;
            --bg: #f5f9ff;
            --surface: #ffffff;
            --surface-alt: #f1f7ff;
            --text: #111827;
            --muted: #475569;
            --border: #dbe7ff;
            --accent: #2563eb;
            --accent-dark: #1d4ed8;
            --shadow: 0 20px 50px rgba(37, 99, 235, 0.13);
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Poppins', Arial, sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
        }
        a { color: inherit; text-decoration: none; }
        img { display: block; max-width: 100%; }
        .navbar {
            position: sticky;
            top: 0;
            z-index: 20;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 8%;
            background: rgba(255,255,255,0.94);
            box-shadow: 0 8px 24px rgba(15,23,42,0.06);
            backdrop-filter: blur(18px);
        }
        .logo { font-size: 1.15rem; font-weight: 700; letter-spacing: 0.24em; }
        .nav-links { display: flex; gap: 22px; list-style: none; flex-wrap: wrap; }
        .nav-links a { color: var(--muted); font-weight: 500; }
        .nav-links a:hover, .user-logout:hover { color: var(--accent); }
        .nav-cta, .user-logout, .btn-white, .btn-outline, button {
            display: inline-flex; align-items: center; justify-content: center; gap: 8px;
            padding: 12px 20px; border-radius: 999px; font-weight: 700; transition: all 0.2s ease;
        }
        .nav-cta, .btn-white, button {
            background: var(--accent); color: #fff; border: 1px solid var(--accent);
        }
        .nav-cta:hover, .btn-white:hover, button:hover { background: var(--accent-dark); }
        .btn-outline { border: 1px solid var(--border); background: #fff; color: var(--text); }
        .btn-outline:hover { background: var(--surface-alt); }
        .hero {
            min-height: 88vh;
            display: grid;
            align-items: center;
            padding: 70px 8% 60px;
            background: linear-gradient(90deg, rgba(245,249,255,0.95) 0%, rgba(241,247,255,0.85) 100%), url('images/begin.jpg') center/cover;
        }
        .hero-content { max-width: 620px; }
        .hero-content h1 { font-size: clamp(2.8rem, 5vw, 4.6rem); line-height: 1.05; margin-bottom: 16px; }
        .hero-content h1 span { color: var(--accent); display: block; }
        .hero-content p { font-size: 1.05rem; color: var(--muted); margin-bottom: 24px; }
        .hero-buttons { display: flex; gap: 12px; flex-wrap: wrap; }
        .stats, .inventory, .about, .why-us, .services, .brands, .testimonials, .contact, footer {
            padding: 70px 8%;
        }
        .stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; background: var(--surface); }
        .stat-box, .car-card, .why-card, .service-card, .testimonial-card, .brand-box, .footer-box {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 24px;
            box-shadow: var(--shadow);
        }
        .stat-box { padding: 24px; text-align: center; }
        .stat-box h2 { color: var(--accent); font-size: 1.8rem; margin-bottom: 6px; }
        .title { text-align: center; max-width: 700px; margin: 0 auto 36px; }
        .title h2 { font-size: clamp(1.8rem, 3vw, 2.4rem); margin-bottom: 10px; }
        .title p, .about-content p, .why-card p, .service-card p, .testimonial-card p, .footer-box p { color: var(--muted); }
        .car-grid, .why-grid, .service-grid, .testimonial-grid, .brand-grid { display: grid; gap: 22px; }
        .car-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .why-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        .service-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        .testimonial-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .brand-grid { grid-template-columns: repeat(6, minmax(0, 1fr)); }
        .car-card, .why-card, .service-card, .testimonial-card, .brand-box { padding: 24px; opacity: 0; transform: translateY(24px); transition: opacity 0.7s ease, transform 0.7s ease; }
        .car-card.reveal, .why-card.reveal, .service-card.reveal, .testimonial-card.reveal, .brand-box.reveal { opacity: 1; transform: translateY(0); }
        .car-image {
            width: 100%;
            height: 220px;
            overflow: hidden;
            border-radius: 18px;
            background: var(--surface-alt);
            margin-bottom: 16px;
        }
        .car-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
        }
        .car-info h3, .why-card h3, .service-card h3, .testimonial-card h3, .footer-box h3 { margin-bottom: 8px; }
        .car-info h4 { color: var(--accent); margin: 12px 0 16px; }
        .about { display: grid; grid-template-columns: 1fr 1fr; gap: 28px; align-items: center; }
        .about-visual { border-radius: 24px; box-shadow: var(--shadow); overflow: hidden; }
        .about-visual img {
            width: 100%;
            height: 100%;
            max-height: 420px;
            object-fit: cover;
            object-position: center;
        }
        .about-content .eyebrow { display: inline-block; margin-bottom: 12px; color: var(--accent); font-weight: 700; letter-spacing: 0.2em; text-transform: uppercase; font-size: 0.8rem; }
        .about-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; margin: 20px 0 24px; }
        .about-card { background: var(--surface-alt); border: 1px solid var(--border); border-radius: 18px; padding: 16px; }
        .contact form { display: grid; gap: 14px; max-width: 680px; margin: 0 auto; }
        input, textarea { width: 100%; padding: 14px 16px; border: 1px solid var(--border); border-radius: 14px; background: #fff; color: var(--text); font: inherit; }
        textarea { min-height: 140px; resize: vertical; }
        footer { background: #f4f8ff; }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .footer-container { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 22px; }
        .footer-box { padding: 24px; }
        .copyright { text-align: center; margin-top: 18px; color: var(--muted); }
        @media (max-width: 1024px) { .stats, .why-grid, .service-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .car-grid, .testimonial-grid, .brand-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .about { grid-template-columns: 1fr; } }
        @media (max-width: 768px) { .navbar { flex-direction: column; gap: 12px; } .stats, .car-grid, .why-grid, .service-grid, .testimonial-grid, .brand-grid, .footer-container, .about-grid { grid-template-columns: 1fr; } .hero { min-height: auto; padding-top: 40px; } }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>


    <nav class="navbar">

        <div class="logo">

            AKAZA'S MOTORS

        </div>

        <ul class="nav-links">

            <li><a href="#home">Home</a></li>
            <li><a href="inventory.php">Inventory</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#reviews">Reviews</a></li>
            <li><a href="#contact">Contact</a></li>
            <?php if (is_logged_in()): ?>
                <li><a href="my-orders.php">My Orders<?php $navCount = get_nav_order_count(); if ($navCount > 0): ?> <span style="display:inline-flex;min-width:18px;height:18px;padding:0 5px;align-items:center;justify-content:center;border-radius:999px;background:var(--accent);color:#fff;font-size:0.7rem;margin-left:4px;vertical-align:middle;"><?php echo $navCount; ?></span><?php endif; ?></a></li>
            <?php endif; ?>
            <?php if (is_admin_user()): ?>
                <li><a href="admin/dashboard.php">Admin</a></li>
            <?php endif; ?>

        </ul>

        <?php if (!empty($_SESSION['username'])): ?>
            <div class="user-area">
                <span class="user-name"><i class="fa fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a class="user-logout" href="login/logout.php"><i class="fa fa-sign-out-alt"></i> Log out</a>
            </div>
        <?php else: ?>
            <a id="signupBtn" class="nav-cta nav-cta-wide" href="login/login.php?form=signup"><i class="fa fa-user-plus"></i> Sign Up</a>
        <?php endif; ?>

    </nav>



  

    <section class="hero" id="home">

        <div class="overlay"></div>

        <div class="hero-content">

            <h1>

                DRIVE

                <span>WITHOUT LIMITS</span>

            </h1>

            <p>

                Premium luxury vehicles.

                Professional service.

                Exceptional driving experience.

            </p>

            <div class="hero-buttons">

                <a href="inventory.php" class="btn-white">

                    View Inventory

                </a>

                <a href="#contact" class="btn-outline">

                    Book Appointment

                </a>

            </div>

        </div>

    </section>



    <!-- ================= STATS ================= -->

    <section class="stats">

        <div class="stat-box">

            <h2>500+</h2>

            <p>Luxury Cars Sold</p>

        </div>

        <div class="stat-box">

            <h2>15+</h2>

            <p>Years Experience</p>

        </div>

        <div class="stat-box">

            <h2>100%</h2>

            <p>Customer Satisfaction</p>

        </div>

        <div class="stat-box">

            <h2>24/7</h2>

            <p>Customer Support</p>

        </div>

    </section>


    <section class="inventory" id="inventory">

        <div class="title">

            <h2>Featured Collection</h2>

            <p>

                Discover a carefully selected collection of luxury vehicles.

            </p>

        </div>

        <div class="car-grid">

            <div class="car-card">

                <div class="car-image">
                    <img src="images/bmw-m4-competition.webp" alt="BMW M4 Competition">
                </div>

                <div class="car-info">

                    <h3>BMW M4 Competition</h3>

                    <p>2025 Model</p>

                    <h4>$65,000</h4>

                    <a href="inventory.php" class="btn-outline">

                        Explore Now

                    </a>

                </div>

            </div>



            <div class="car-card">

                <div class="car-image">
                    <img src="images/mercedes-c63-amg.jpg" alt="Mercedes-Benz C63 AMG">
                </div>

                <div class="car-info">

                    <h3>Mercedes-Benz C63 AMG</h3>

                    <p>2025 Model</p>

                    <h4>$83,000</h4>

                    <a href="inventory.php" class="btn-outline">

                        Explore Now

                    </a>

                </div>

            </div>



            <div class="car-card">

                <div class="car-image">
                    <img src="images/audi-rs7.jpg" alt="Audi RS7">
                </div>

                <div class="car-info">

                    <h3>Audi RS7</h3>

                    <p>2025 Model</p>

                    <h4>$91,000</h4>

                    <a href="inventory.php" class="btn-outline">

                        Explore Now

                    </a>

                </div>

            </div>

        </div>

    </section>
     

    <section class="about" id="about">

        <div class="about-visual">
            <img src="images/aboutuspicture.jpg" alt="Akaza's Motors showroom">
        </div>

        <div class="about-content">
            <p class="eyebrow">Our Promise</p>
            <h2>Where Passion Meets Performance</h2>
            <p>At Akaza's Motors, we curate elite vehicles for drivers who demand precision, luxury, and iconic style. Every model is chosen for performance, craftsmanship, and unforgettable presence on the road.</p>
            <div class="about-grid">
                <div class="about-card">
                    <h3>Premium Selection</h3>
                    <p>Hand-picked luxury vehicles from world-class brands.</p>
                </div>
                <div class="about-card">
                    <h3>White-glove Service</h3>
                    <p>Personalized support from browsing to delivery.</p>
                </div>
            </div>
            <a href="#" class="btn-white">Explore Collection</a>
        </div>

    </section>



  

    <section class="why-us">

        <div class="title">

            <h2>Why Choose Akaza's Motors?</h2>

            <p>

                Experience professionalism, trust, and luxury.

            </p>

        </div>

        <div class="why-grid">

            <div class="why-card">

                <h3>Luxury Inventory</h3>

                <p>

                    Hand-picked premium vehicles from trusted manufacturers.

                </p>

            </div>

            <div class="why-card">

                <h3>Affordable Financing</h3>

                <p>

                    Flexible financing plans designed for every customer.

                </p>

            </div>

            <div class="why-card">

                <h3>Certified Vehicles</h3>

                <p>

                    Every vehicle undergoes professional inspection before sale.

                </p>

            </div>

            <div class="why-card">

                <h3>Trusted Experts</h3>

                <p>

                    Experienced professionals ready to assist you anytime.

                </p>

            </div>

        </div>

    </section>


    <section class="services" id="services">

        <div class="title">

            <h2>Our Services</h2>

        </div>

        <div class="service-grid">

            <div class="service-card">

                <h3>Luxury Car Sales</h3>

                <p>

                    Discover the latest premium vehicles available today.

                </p>
                

            </div>

            <div class="service-card">

                <h3>Vehicle Financing</h3>

                <p>

                    Convenient payment options with competitive rates.

                </p>

            </div>

            <div class="service-card">

                <h3>Trade-In Service</h3>

                <p>

                    Upgrade your vehicle with our trade-in program.

                </p>

            </div>

            <div class="service-card">

                <h3>Maintenance</h3>

                <p>

                    Professional servicing performed by certified technicians.

                </p>

            </div>

        </div>

    </section>


    <section class="brands">

        <div class="title">

            <h2>Luxury Brands</h2>

        </div>

        <div class="brand-grid">

            <div class="brand-box">BMW</div>

            <div class="brand-box">Mercedes</div>

            <div class="brand-box">Audi</div>

            <div class="brand-box">Porsche</div>

            <div class="brand-box">Lexus</div>

            <div class="brand-box">Ferrari</div>

        </div>

    </section>


    <section class="testimonials" id="reviews">

        <div class="title">

            <h2>What Our Customers Say</h2>

            <p>
                Trusted by luxury car enthusiasts.
            </p>

        </div>

        <div class="testimonial-grid">

            <div class="testimonial-card">

                <p>

                    "Outstanding customer service. Buying my dream car was
                    simple and stress-free."

                </p>

                <h3>- Michael Johnson</h3>

            </div>

            <div class="testimonial-card">

                <p>

                    "Professional staff and premium vehicles. Highly
                    recommended."

                </p>

                <h3>- Sarah Williams</h3>

            </div>

            <div class="testimonial-card">

                <p>

                    "One of the best luxury dealerships I've visited.
                    Amazing experience."

                </p>

                <h3>- David Brown</h3>

            </div>

        </div>

    </section>


    <section class="contact" id="contact">

        <div class="title">

            <h2>Book An Appointment</h2>

            <p>

                We'd love to help you find your perfect vehicle.

            </p>

        </div>

        <form>

            <input
                type="text"
                placeholder="Full Name"
            >

            <input
                type="email"
                placeholder="Email Address"
            >

            <input
                type="text"
                placeholder="Phone Number"
            >

            <textarea
                placeholder="Tell us which vehicle you're interested in..."
            ></textarea>

            <button>

                Submit

            </button>

        </form>

    </section>


    <script>
        const revealItems = document.querySelectorAll('.car-card, .why-card, .service-card, .testimonial-card, .brand-box');
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('reveal');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        revealItems.forEach((item) => revealObserver.observe(item));
    </script>

    <footer>

        <div class="footer-container">

            <div class="footer-box">

                <h3>

                    AKAZA'S MOTORS

                </h3>

                <p>

                    Luxury.
                    Performance.
                    Excellence.

                </p>

            </div>

            <div class="footer-box">

                <h3>

                    Quick Links

                </h3>

                <a href="#home">

                    Home

                </a>

                <a href="#inventory">

                    Inventory

                </a>

                <a href="#about">

                    About

                </a>

                <a href="#services">

                    Services

                </a>

                <a href="#contact">

                    Contact

                </a>

            </div>

            <div class="footer-box">

                <h3>

                    Contact

                </h3>

                <p>

                    Lagos, Nigeria

                </p>

                <p>

                    +234 000 000 0000

                </p>

                <p>

                    info@akazasmotors.com

                </p>

            </div>

        </div>

        <hr>

        <p class="copyright">

            © 2026 Akaza's Motors.
            All Rights Reserved.

        </p>

    </footer>

</body>

</html>
</body>

</html>