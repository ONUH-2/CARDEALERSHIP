<?php
session_start();

require_once __DIR__ . '/../../form/inc/connect.php';

$message = '';
$signupErrors = [];
$activeForm = (($_GET['form'] ?? '') === 'signup') ? 'signup' : 'login';

if (!isset($con) || $con === false) {
    $message = 'Database unavailable. Please try again later.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($con) && $con !== false) {
    $formType = $_POST['form_type'] ?? 'login';
    $activeForm = $formType === 'signup' ? 'signup' : 'login';

    if ($formType === 'signup') {
        $fullname = trim($_POST['fullname'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $confirmPassword = (string)($_POST['confirm_password'] ?? '');

        if ($fullname === '') $signupErrors[] = 'Please enter your full name.';
        if ($username === '') $signupErrors[] = 'Please enter a username.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $signupErrors[] = 'Please enter a valid email address.';
        if (strlen($password) < 6) $signupErrors[] = 'Password must be at least 6 characters long.';
        if ($password !== $confirmPassword) $signupErrors[] = 'Passwords do not match.';

        if (!$signupErrors) {
            $check = $con->prepare('SELECT id FROM user_data WHERE email = ? OR username = ? LIMIT 1');
            if (!$check) {
                $signupErrors[] = 'Could not validate your account details. Please try again.';
            } else {
                $check->bind_param('ss', $email, $username);
                $check->execute();
                $existing = $check->get_result()->fetch_assoc();
                $check->close();

                if ($existing) {
                    $signupErrors[] = 'That email or username is already registered.';
                }
            }
        }

        if (!$signupErrors) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $con->prepare('INSERT INTO user_data (fullname, username, email, password) VALUES (?, ?, ?, ?)');
            if (!$stmt) {
                $signupErrors[] = 'Could not create your account. Please check your database setup.';
            } else {
                $stmt->bind_param('ssss', $fullname, $username, $email, $hashedPassword);
                if ($stmt->execute()) {
                    $message = 'Account created successfully. You can now log in.';
                    $activeForm = 'login';
                    $_POST = [];
                } else {
                    $signupErrors[] = 'Could not create your account. Please try again.';
                }
                $stmt->close();
            }
        }
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');

        if ($email !== '' && $password !== '') {
            $stmt = $con->prepare('SELECT id, username, email, password FROM user_data WHERE email = ?');
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                $storedPassword = (string)$user['password'];

                if (password_verify($password, $storedPassword) || hash_equals($storedPassword, $password)) {
                    $_SESSION['user_id'] = (int)$user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    header('Location: ../../cardealership/index.php');
                    exit;
                }

                $message = 'Wrong password. Please try again.';
            } else {
                $message = 'No account found with that email.';
            }
            $stmt->close();
        } else {
            $message = 'Please fill in both fields.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Akaza's Motors | Login & Sign Up</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f5f9ff;
      --panel: #ffffff;
      --panel-soft: #f1f7ff;
      --text: #111827;
      --muted: #475569;
      --border: #dbe7ff;
      --accent: #2563eb;
      --accent-dark: #1d4ed8;
      --shadow: 0 24px 60px rgba(37, 99, 235, 0.16);
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      font-family: 'Poppins', Arial, sans-serif;
      background: linear-gradient(135deg, #f8fbff 0%, #eef6ff 100%);
      color: var(--text);
    }
    .auth-shell {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 30px;
    }
    .auth-card {
      width: min(100%, 1000px);
      display: grid;
      grid-template-columns: 1.02fr 0.98fr;
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 28px;
      overflow: hidden;
      box-shadow: var(--shadow);
    }
    .brand-panel {
      padding: 46px;
      background: linear-gradient(160deg, #f4f9ff 0%, #eaf3ff 100%);
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 16px;
    }
    .eyebrow { color: var(--accent); text-transform: uppercase; letter-spacing: 0.24em; font-size: 0.78rem; font-weight: 700; }
    .brand-panel h1 { font-size: clamp(1.8rem, 3vw, 2.6rem); line-height: 1.1; }
    .brand-panel p { color: var(--muted); line-height: 1.7; }
    .info-list { display: grid; gap: 8px; margin-top: 10px; }
    .info-list span { color: var(--text); font-weight: 600; }
    .form-panel { padding: 42px; display: flex; flex-direction: column; justify-content: center; }
    .tabs { display: flex; gap: 12px; margin-bottom: 24px; }
    .tab-btn { flex: 1; padding: 12px 14px; border: 1px solid var(--border); border-radius: 999px; background: var(--panel-soft); color: var(--text); font-weight: 600; cursor: pointer; }
    .tab-btn.active { background: var(--accent); color: #fff; border-color: var(--accent); }
    .auth-form { display: none; gap: 14px; }
    .auth-form.active { display: flex; flex-direction: column; }
    label { font-weight: 600; color: var(--text); }
    input { width: 100%; padding: 13px 14px; border: 1px solid var(--border); border-radius: 14px; font: inherit; color: var(--text); background: #fff; }
    .submit-btn { margin-top: 10px; padding: 14px; border: none; border-radius: 999px; background: var(--accent); color: #fff; font-weight: 700; cursor: pointer; }
    .submit-btn:hover { background: var(--accent-dark); }
    .switch-text { margin-top: 10px; color: var(--muted); }
    .switch-link { color: var(--accent); font-weight: 700; }
    @media (max-width: 840px) { .auth-card { grid-template-columns: 1fr; } .brand-panel { padding-bottom: 24px; } .form-panel { padding-top: 16px; } }
  </style>

</head>
<body>
  <div class="auth-shell">
    <div class="auth-card">
      <div class="brand-panel">
        <p class="eyebrow">Luxury Performance</p>
        <h1>Welcome to<br>Akaza's Motors</h1>
        <p>Join the exclusive club for premium service, private offers, and priority access to the latest luxury vehicles.</p>

        <div class="info-list">
          <span>✓ Premium inventory access</span>
          <span>✓ Priority appointments</span>
          <span>✓ VIP offers and events</span>
        </div>
      </div>

      <div class="form-panel">
        <div class="tabs">
          <button class="tab-btn <?php echo $activeForm === 'login' ? 'active' : ''; ?>" data-form="login">Login</button>
          <button class="tab-btn <?php echo $activeForm === 'signup' ? 'active' : ''; ?>" data-form="signup">Sign up</button>
        </div>

        <?php if (!empty($message)) { ?>
          <div style="color:#15803d;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:11px 13px;margin-bottom:14px;">
            <?php echo htmlspecialchars($message); ?>
          </div>
        <?php } ?>

        <?php if (!empty($signupErrors)) { ?>
          <div style="color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;border-radius:12px;padding:11px 13px;margin-bottom:14px;">
            <?php foreach ($signupErrors as $signupError) { ?>
              <div><?php echo htmlspecialchars($signupError); ?></div>
            <?php } ?>
          </div>
        <?php } ?>

        <form class="auth-form <?php echo $activeForm === 'login' ? 'active' : ''; ?>" id="login-form" method="POST" action="">
          <input type="hidden" name="form_type" value="login">
          <label for="login-email">Email</label>
          <input type="email" id="login-email" name="email" placeholder="you@example.com" required>

          <label for="login-password">Password</label>
          <input type="password" id="login-password" name="password" placeholder="••••••••" required>

          <button type="submit" class="submit-btn" name="submit" value="1">Sign In</button>
          <p class="switch-text">New here? <a href="#" class="switch-link" data-form="signup">Create account</a></p>
        </form>

        <form class="auth-form <?php echo $activeForm === 'signup' ? 'active' : ''; ?>" id="signup-form" method="POST" action="">
          <input type="hidden" name="form_type" value="signup">
          <label for="signup-name">Full Name</label>
          <input type="text" id="signup-name" name="fullname" placeholder="John Doe" required>

          <label for="signup-username">Username</label>
          <input type="text" id="signup-username" name="username" placeholder="johndoe" required>

          <label for="signup-email">Email</label>
          <input type="email" id="signup-email" name="email" placeholder="you@example.com" required>

          <label for="signup-password">Password</label>
          <input type="password" id="signup-password" name="password" placeholder="Create a password" required>

          <label for="signup-confirm">Confirm Password</label>
          <input type="password" id="signup-confirm" name="confirm_password" placeholder="Repeat password" required>

          <button type="submit" class="submit-btn" name="submit" value="1">Create Account</button>
          <p class="switch-text">Already have an account? <a href="#" class="switch-link" data-form="login">Log in</a></p>
        </form>
      </div>
    </div>
  </div>

  <script>
    const tabs = document.querySelectorAll('.tab-btn');
    const forms = document.querySelectorAll('.auth-form');
    const switches = document.querySelectorAll('.switch-link');

    function showForm(target) {
      forms.forEach(form => form.classList.toggle('active', form.id === `${target}-form`));
      tabs.forEach(tab => tab.classList.toggle('active', tab.dataset.form === target));
    }

    tabs.forEach(tab => {
      tab.addEventListener('click', (event) => {
        event.preventDefault();
        showForm(tab.dataset.form);
      });
    });

    switches.forEach(link => {
      link.addEventListener('click', (event) => {
        event.preventDefault();
        showForm(link.dataset.form);
      });
    });
  </script>
</body>
</html>
