<?php
require_once __DIR__ . '/auth.php';

function get_nav_order_count(): int {
    global $con;
    if (!is_logged_in()) return 0;
    if (!isset($con)) {
        @require_once __DIR__ . '/../../form/inc/connect.php';
    }
    if (!isset($con) || $con === false) return 0;
    $stmt = $con->prepare('SELECT COUNT(*) AS total FROM orders WHERE user_id = ?');
    if (!$stmt) return 0;
    $userId = (int)($_SESSION['user_id'] ?? 0);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return (int)($row['total'] ?? 0);
}

function render_navbar(string $active = ''): void {
    $isLoggedIn = is_logged_in();
    $isAdmin = is_admin_user();
    $orderCount = get_nav_order_count();
    echo '<nav class="navbar">';
    echo '<div class="logo">AKAZA\'S MOTORS</div>';
    echo '<ul class="nav-links">';
    $items = [
        ['href' => '/cardealership/index.php', 'label' => 'Home'],
        ['href' => '/cardealership/inventory.php', 'label' => 'Inventory'],
    ];
    if ($isLoggedIn) {
        $items[] = ['href' => '/cardealership/my-orders.php', 'label' => 'My Orders'];
    }
    foreach ($items as $item) {
        $class = $active === $item['label'] ? 'active' : '';
        $suffix = ($item['label'] === 'My Orders' && $orderCount > 0) ? ' <span style="display:inline-flex;min-width:18px;height:18px;padding:0 5px;align-items:center;justify-content:center;border-radius:999px;background:var(--accent);color:#fff;font-size:.7rem;margin-left:4px;vertical-align:middle;">' . $orderCount . '</span>' : '';
        echo '<li><a class="' . esc($class) . '" href="' . esc($item['href']) . '">' . esc($item['label']) . $suffix . '</a></li>';
    }
    if ($isAdmin) {
        echo '<li><a class="' . esc($active === 'Admin' ? 'active' : '') . '" href="/cardealership/admin/dashboard.php">Admin</a></li>';
    }
    echo '</ul>';
    if ($isLoggedIn) {
        echo '<div class="user-area"><span class="user-name"><i class="fa fa-user-circle"></i> ' . esc($_SESSION['username']) . '</span><a class="user-logout" href="/cardealership/login/logout.php"><i class="fa fa-sign-out-alt"></i> Log out</a></div>';
    } else {
        echo '<a class="nav-cta" href="/cardealership/login/login.php?form=signup"><i class="fa fa-user-plus"></i> Sign Up</a>';
    }
    echo '</nav>';
}

function render_page_start(string $title): void {
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>' . esc($title) . '</title>';
    echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />';
    echo '<style>';
    echo ':root{color-scheme:light;--bg:#f5f9ff;--surface:#ffffff;--surface-alt:#f1f7ff;--text:#111827;--muted:#475569;--border:#dbe7ff;--accent:#2563eb;--accent-dark:#1d4ed8;--shadow:0 18px 45px rgba(37,99,235,0.12)}*{box-sizing:border-box;margin:0;padding:0}body{font-family:Poppins,Arial,sans-serif;background:var(--bg);color:var(--text);line-height:1.6}a{color:inherit;text-decoration:none}img{display:block;max-width:100%}.navbar{position:sticky;top:0;z-index:20;display:flex;justify-content:space-between;align-items:center;padding:20px 8%;background:rgba(255,255,255,0.94);box-shadow:0 8px 24px rgba(15,23,42,0.06);backdrop-filter:blur(18px)}.logo{font-size:1.15rem;font-weight:700;letter-spacing:.24em}.nav-links{display:flex;gap:22px;list-style:none;flex-wrap:wrap}.nav-links a{color:var(--muted);font-weight:500}.nav-links a.active,.nav-links a:hover,.user-logout:hover{color:var(--accent)}.user-area{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.user-name{font-weight:600}.nav-cta,.user-logout,.btn,.btn-primary,.btn-secondary,.btn-danger{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:11px 18px;border-radius:999px;font-weight:700;transition:all .2s ease}.nav-cta,.btn-primary{background:var(--accent);color:#fff;border:1px solid var(--accent)}.nav-cta:hover,.btn-primary:hover{background:var(--accent-dark)}.btn-secondary{background:#fff;border:1px solid var(--border);color:var(--text)}.btn-secondary:hover{background:var(--surface-alt)}.btn-danger{background:#dc2626;color:#fff;border:1px solid #dc2626}.page{padding:40px 8% 80px;max-width:1400px;margin:0 auto}.card{background:var(--surface);border:1px solid var(--border);border-radius:24px;box-shadow:var(--shadow);padding:24px}.grid{display:grid;gap:20px}.grid-2{grid-template-columns:repeat(2,minmax(0,1fr))}.grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px}.stat{background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:24px}.stat h3{font-size:1.8rem;color:var(--accent)}table{width:100%;border-collapse:collapse;background:#fff;border:1px solid var(--border);border-radius:12px;overflow:hidden}th,td{padding:12px 14px;border-bottom:1px solid var(--border);text-align:left}th{background:var(--surface-alt)}input,select,textarea{width:100%;padding:12px 14px;border:1px solid var(--border);border-radius:14px;font:inherit}form{display:grid;gap:14px}.actions{display:flex;gap:10px;flex-wrap:wrap}.muted{color:var(--muted)}.success{color:#15803d;font-weight:600}.error{color:#dc2626;font-weight:600}.pill{display:inline-block;padding:7px 12px;border-radius:999px;background:var(--surface-alt);font-size:.9rem}.table-wrap{overflow-x:auto}@media (max-width:900px){.stats,.grid-2,.grid-3{grid-template-columns:1fr}.navbar{flex-direction:column;gap:12px}}';
    echo '</style>';
    echo '</head><body>';
}

function render_page_end(): void {
    echo '</body></html>';
}
