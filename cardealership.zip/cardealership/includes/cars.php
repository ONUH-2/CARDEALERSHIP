<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../../form/inc/connect.php';

function normalize_car(array $car): array {
    $images = [];
    if (array_key_exists('images', $car)) {
        $raw = $car['images'];
        if (is_array($raw)) {
            $images = $raw;
        } else {
            $raw = trim((string)$raw);
            if ($raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $images = $decoded;
                } else {
                    $images = preg_split('/\s*,\s*/', $raw);
                }
            }
        }
    }

    $features = [];
    if (array_key_exists('features', $car)) {
        $raw = $car['features'];
        if (is_array($raw)) {
            $features = $raw;
        } else {
            $raw = trim((string)$raw);
            if ($raw !== '') {
                $decoded = json_decode($raw, true);
                $features = is_array($decoded)
                    ? $decoded
                    : preg_split('/\r\n|\r|\n/', $raw);
            }
        }
    }

    $car['images'] = array_values(array_filter(array_map(
        static fn($value) => trim((string)$value),
        $images
    )));
    $car['features'] = array_values(array_filter(array_map(
        static fn($value) => trim((string)$value),
        $features
    )));

    return $car;
}

function legacy_cars(): array {
    static $cars = null;
    if ($cars !== null) {
        return $cars;
    }

    $cars = [];
    $file = __DIR__ . '/../cars_data.php';
    if (is_file($file)) {
        $data = include $file;
        if (is_array($data)) {
            foreach ($data as $car) {
                if (is_array($car)) {
                    $cars[] = normalize_car($car);
                }
            }
        }
    }

    return $cars;
}

function get_database_cars(bool $includeHidden = false): array {
    global $con;
    if (!isset($con) || $con === false) {
        return [];
    }

    $sql = $includeHidden
        ? 'SELECT * FROM cars ORDER BY created_at DESC, id DESC'
        : "SELECT * FROM cars WHERE status IS NULL OR TRIM(status) = '' OR LOWER(status) <> 'hidden' ORDER BY created_at DESC, id DESC";

    $result = $con->query($sql);
    if (!$result) {
        return [];
    }

    $cars = [];
    while ($row = $result->fetch_assoc()) {
        $cars[] = normalize_car($row);
    }

    return $cars;
}

function get_all_cars(bool $includeHidden = false): array {
    $legacy = legacy_cars();
    $database = get_database_cars($includeHidden);

    // Keep every original demo car, while letting a DB record replace a demo
    // record only when it explicitly uses the same positive ID.
    $byId = [];
    foreach ($legacy as $index => $car) {
        $id = (int)($car['id'] ?? 0);
        $key = $id > 0 ? 'id:' . $id : 'legacy:' . $index;
        $byId[$key] = $car;
    }

    foreach ($database as $index => $car) {
        $id = (int)($car['id'] ?? 0);
        $key = $id > 0 ? 'id:' . $id : 'db:' . $index;
        $byId[$key] = $car;
    }

    return array_values($byId);
}

function get_car_by_id(int $id, bool $includeHidden = false): ?array {
    global $con;
    if ($id <= 0) {
        return null;
    }

    if (isset($con) && $con !== false) {
        $sql = $includeHidden
            ? 'SELECT * FROM cars WHERE id = ? LIMIT 1'
            : "SELECT * FROM cars WHERE id = ? AND (status IS NULL OR TRIM(status) = '' OR LOWER(status) <> 'hidden') LIMIT 1";

        $stmt = $con->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $car = ($result && $result->num_rows > 0) ? $result->fetch_assoc() : null;
            $stmt->close();

            if ($car) {
                return normalize_car($car);
            }
        }
    }

    foreach (legacy_cars() as $car) {
        if ((int)($car['id'] ?? 0) === $id) {
            return $car;
        }
    }

    return null;
}

function car_image_url(string $image): string {
    $image = trim($image);
    if ($image === '') {
        return '/cardealership/images/placeholder.svg';
    }
    if (preg_match('#^https?://#i', $image)) {
        return $image;
    }
    return '/cardealership/' . ltrim($image, '/');
}

function first_car_image(array $car): string {
    return !empty($car['images'][0])
        ? (string)$car['images'][0]
        : 'images/placeholder.svg';
}

function save_uploaded_car_images(array $fileData): array {
    $uploaded = [];
    $errors = [];

    if (!isset($fileData['name']) || !is_array($fileData['name'])) {
        return ['paths' => [], 'errors' => []];
    }

    $uploadDir = __DIR__ . '/../uploads/cars/';
    if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
        return ['paths' => [], 'errors' => ['The image upload folder could not be created.']];
    }

    $maxBytes = 8 * 1024 * 1024;
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    foreach ($fileData['name'] as $i => $originalName) {
        $errorCode = (int)($fileData['error'][$i] ?? UPLOAD_ERR_NO_FILE);
        if ($errorCode === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($errorCode !== UPLOAD_ERR_OK) {
            $errors[] = 'Could not upload ' . (string)$originalName . ' (upload error ' . $errorCode . ').';
            continue;
        }

        $tmpName = $fileData['tmp_name'][$i] ?? '';
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            $errors[] = 'The uploaded file ' . (string)$originalName . ' was not received correctly.';
            continue;
        }

        if (($fileData['size'][$i] ?? 0) > $maxBytes) {
            $errors[] = (string)$originalName . ' is larger than 8 MB.';
            continue;
        }

        $imageInfo = @getimagesize($tmpName);
        if ($imageInfo === false || empty($imageInfo['mime']) || !isset($allowed[$imageInfo['mime']])) {
            $errors[] = (string)$originalName . ' is not a supported image. Use JPG, PNG, or WebP.';
            continue;
        }

        $extension = $allowed[$imageInfo['mime']];
        $fileName = 'car_' . bin2hex(random_bytes(10)) . '.' . $extension;
        $destination = $uploadDir . $fileName;

        if (!move_uploaded_file($tmpName, $destination)) {
            $errors[] = 'The server could not save ' . (string)$originalName . '.';
            continue;
        }

        $uploaded[] = 'uploads/cars/' . $fileName;
    }

    return ['paths' => $uploaded, 'errors' => $errors];
}
