<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../../form/inc/connect.php';

require_admin();

$search = trim($_GET['search'] ?? '');
$paymentFilter = trim($_GET['payment_status'] ?? '');
$orderFilter = trim($_GET['order_status'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

$stats = [];
$orders = [];
if ($con && $con !== false) {
    $statsQuery = $con->query('SELECT (SELECT COUNT(*) FROM user_data) AS users, (SELECT COUNT(*) FROM cars) AS cars, (SELECT COUNT(*) FROM orders) AS orders, (SELECT COUNT(*) FROM orders WHERE payment_status = "Pending") AS pending, (SELECT COUNT(*) FROM orders WHERE order_status = "Completed") AS completed, (SELECT COALESCE(SUM(amount),0) FROM orders) AS revenue');
    if ($statsQuery) {
        $stats = $statsQuery->fetch_assoc();
    }

    $where = [];
    $params = [];
    $types = '';
    if ($search !== '') { $where[] = '(u.username LIKE ? OR u.email LIKE ? OR c.name LIKE ?)'; $like = '%' . $search . '%'; $params[] = $like; $params[] = $like; $params[] = $like; $types .= 'sss'; }
    if ($paymentFilter !== '') { $where[] = 'o.payment_status = ?'; $params[] = $paymentFilter; $types .= 's'; }
    if ($orderFilter !== '') { $where[] = 'o.order_status = ?'; $params[] = $orderFilter; $types .= 's'; }
    $sql = 'SELECT o.id AS order_id, u.username, u.email, c.name AS car_name, o.amount, o.payment_method, o.payment_status, o.order_status, o.created_at FROM orders o JOIN user_data u ON u.id = o.user_id JOIN cars c ON c.id = o.car_id';
    if (!empty($where)) { $sql .= ' WHERE ' . implode(' AND ', $where); }
    $sql .= ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
    $stmt = $con->prepare($sql);
    if ($stmt) {
        $params[] = $perPage;
        $params[] = $offset;
        $types .= 'ii';
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
        $stmt->close();
    }
}

render_page_start('Admin Dashboard');
render_navbar('');
echo '<div class="page"><div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap"><div><h2>Admin Dashboard</h2><p class="muted">Manage orders, customers, and inventory from one place.</p></div><div class="actions"><a class="btn-primary" href="add-car.php">+ Add Car</a><a class="btn-secondary" href="cars.php">Manage Cars</a><a class="btn-secondary" href="users.php">Users</a></div></div></div>';
echo '<div class="stats" style="margin-top:20px;">';
$cards = [['label'=>'Total Users','value'=>$stats['users'] ?? 0],['label'=>'Total Cars','value'=>$stats['cars'] ?? 0],['label'=>'Total Orders','value'=>$stats['orders'] ?? 0],['label'=>'Pending Orders','value'=>$stats['pending'] ?? 0],['label'=>'Completed Orders','value'=>$stats['completed'] ?? 0],['label'=>'Total Revenue','value'=>'$' . number_format((float) ($stats['revenue'] ?? 0), 2)]];
foreach ($cards as $card) {
    echo '<div class="stat"><p class="muted">' . esc($card['label']) . '</p><h3>' . esc($card['value']) . '</h3></div>';
}
echo '</div>';
echo '<div class="card" style="margin-top:24px;">';
echo '<form method="get" style="display:grid;grid-template-columns:2fr 1fr 1fr auto;gap:12px;align-items:end;">';
echo '<div><label>Search</label><input type="text" name="search" value="' . esc($search) . '" placeholder="Search orders"></div>';
echo '<div><label>Payment Status</label><select name="payment_status"><option value="">All</option><option value="Pending"' . ($paymentFilter === 'Pending' ? ' selected' : '') . '>Pending</option><option value="Paid"' . ($paymentFilter === 'Paid' ? ' selected' : '') . '>Paid</option></select></div>';
echo '<div><label>Order Status</label><select name="order_status"><option value="">All</option><option value="Processing"' . ($orderFilter === 'Processing' ? ' selected' : '') . '>Processing</option><option value="Preparing Vehicle"' . ($orderFilter === 'Preparing Vehicle' ? ' selected' : '') . '>Preparing Vehicle</option><option value="Ready for Pickup"' . ($orderFilter === 'Ready for Pickup' ? ' selected' : '') . '>Ready for Pickup</option><option value="Completed"' . ($orderFilter === 'Completed' ? ' selected' : '') . '>Completed</option><option value="Cancelled"' . ($orderFilter === 'Cancelled' ? ' selected' : '') . '>Cancelled</option></select></div>';
echo '<button class="btn-primary" type="submit">Filter</button>';
echo '</form>';
echo '<div class="table-wrap" style="margin-top:16px;"><table><thead><tr><th>Order ID</th><th>Customer</th><th>Car</th><th>Price</th><th>Payment</th><th>Payment Status</th><th>Order Status</th><th>Actions</th></tr></thead><tbody>';
if (empty($orders)) {
    echo '<tr><td colspan="8">No orders found.</td></tr>';
} else {
    foreach ($orders as $order) {
        echo '<tr>';
        echo '<td>#' . esc($order['order_id']) . '</td>';
        echo '<td>' . esc($order['username']) . '<br><span class="muted">' . esc($order['email']) . '</span></td>';
        echo '<td>' . esc($order['car_name']) . '</td>';
        echo '<td>$' . esc(number_format((float) $order['amount'], 2)) . '</td>';
        echo '<td>' . esc($order['payment_method']) . '</td>';
        echo '<td><span class="pill">' . esc($order['payment_status']) . '</span></td>';
        echo '<td><span class="pill">' . esc($order['order_status']) . '</span></td>';
        echo '<td><div class="actions"><a class="btn-primary" href="confirm-payment.php?order_id=' . (int)$order['order_id'] . '">Review / Confirm</a><a class="btn-secondary" href="order-actions.php?order_id=' . (int)$order['order_id'] . '&action=mark_paid">Paid</a></div></td>';
        echo '</tr>';
    }
}
echo '</tbody></table></div>';
echo '</div></div>';
render_page_end();
