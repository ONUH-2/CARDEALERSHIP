<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/cars.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$car = get_car_by_id($id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $car ? htmlspecialchars($car['name']) : 'Vehicle Not Found'; ?> | Akaza's Motors</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        :root {
            color-scheme: light;
            --bg: #f5f9ff;
            --panel: #ffffff;
            --panel-border: #dbe7ff;
            --surface: #f1f7ff;
            --surface-strong: #eaf3ff;
            --text: #111827;
            --text-muted: #475569;
            --accent: #2563eb;
            --accent-soft: rgba(37,99,235,0.12);
            --shadow: 0 24px 70px rgba(37, 99, 235, 0.12);
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
            min-height: 100vh;
            font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(180deg, #f9fcff 0%, #f2f7ff 100%);
            color: var(--text);
        }
        a { color: inherit; text-decoration: none; }
        img { max-width: 100%; display: block; }
        .navbar {
            position: fixed; inset: 0 0 auto 0; z-index: 20;
            display: flex; justify-content: space-between; align-items: center;
            padding: 18px 8%; background: rgba(255,255,255,0.92); border-bottom: 1px solid var(--panel-border); backdrop-filter: blur(18px);
        }
        .logo { font-size: 0.95rem; font-weight: 700; letter-spacing: 0.45em; text-transform: uppercase; color: var(--text); }
        .nav-links { display: flex; gap: 26px; list-style: none; }
        .nav-links a { font-size: 0.95rem; color: var(--text-muted); transition: color 0.22s ease; position: relative; }
        .nav-links a:hover { color: var(--accent); }
        .nav-links a::after { content: ''; position: absolute; left: 0; bottom: -8px; width: 0; height: 2px; background: var(--accent); transition: width 0.25s ease; }
        .nav-links a:hover::after { width: 100%; }
        .user-area { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
        .user-name { color: var(--text); font-weight: 600; display: inline-flex; align-items: center; gap: 8px; }
        .user-logout { color: var(--accent); font-weight: 600; display: inline-flex; align-items: center; gap: 8px; }
        .nav-cta { display: inline-flex; align-items: center; gap: 8px; padding: 11px 18px; border-radius: 999px; background: var(--accent); color: #fff; font-weight: 700; text-decoration: none; }
        .nav-cta:hover { background: var(--accent); }
        .details-page { padding: 140px 8% 80px; display: flex; justify-content: center; width: 100%; }
        .details-panel { width: min(100%, 1320px); margin: 0 auto; background: var(--panel); border: 1px solid var(--panel-border); border-radius: 28px; box-shadow: var(--shadow); overflow: hidden; }
        .details-panel.not-found { padding: 90px 60px; text-align: center; }
        .details-panel.not-found h1 { font-size: clamp(2.4rem, 3vw, 3.4rem); margin-bottom: 18px; color: var(--text); }
        .details-panel.not-found p { color: var(--text-muted); margin-bottom: 30px; font-size: 1rem; max-width: 600px; margin-left: auto; margin-right: auto; }
        .details-panel.not-found .btn-white { display: inline-flex; padding: 14px 32px; }
        .details-hero { display: grid; grid-template-columns: 1.18fr 0.82fr; gap: 28px; align-items: stretch; padding: 42px 42px 22px; }
        .details-hero-copy { display: flex; flex-direction: column; gap: 18px; }
        .eyebrow { display: inline-flex; align-items: center; gap: 10px; color: var(--accent); text-transform: uppercase; letter-spacing: 0.28em; font-size: 0.78rem; }
        .eyebrow::before { content: ''; width: 42px; height: 1px; background: rgba(37,99,235,0.16); }
        .details-hero-copy h1 { font-size: clamp(2.4rem, 3.5vw, 3.6rem); line-height: 1.05; color: var(--text); }
        .subtext { color: var(--text-muted); font-size: 0.98rem; max-width: 620px; margin-bottom: 18px; }
        .details-badges { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 22px; }
        .badge { display: inline-flex; align-items: center; padding: 10px 16px; border-radius: 999px; background: var(--surface); border: 1px solid var(--panel-border); color: var(--text); font-size: 0.9rem; }
        .details-actions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; margin-top: 12px; }
        .details-actions > a { width: 100%; }
        .btn-white, .btn-outline { display: inline-flex; align-items: center; justify-content: center; padding: 14px 24px; border-radius: 999px; font-weight: 700; transition: all 0.24s ease; min-height: 50px; }
        .btn-white { background: var(--accent); color: #fff; box-shadow: 0 20px 40px rgba(37,99,235,0.16); }
        .btn-white:hover { transform: translateY(-2px); background: var(--accent); }
        .btn-outline { border: 1px solid var(--panel-border); background: var(--surface); color: var(--text); }
        .btn-outline:hover { background: var(--surface-strong); }
        .details-hero-media { position: relative; border-radius: 26px; overflow: hidden; min-height: 300px; max-height: 380px; border: 1px solid var(--panel-border); }
        .details-hero-media img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.35s ease; }
        .details-hero-media:hover img { transform: scale(1.03); }
        .price-chip { position: absolute; bottom: 24px; left: 24px; background: var(--accent); color: #fff; padding: 14px 26px; border-radius: 999px; font-weight: 700; letter-spacing: 0.02em; box-shadow: 0 18px 36px rgba(37,99,235,0.18); }
        .stat-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 20px; padding: 0 46px 40px; }
        .stat-card { background: var(--surface); border: 1px solid var(--panel-border); border-radius: 22px; padding: 28px; text-align: center; color: var(--text); }
        .stat-card span { display: block; margin-bottom: 10px; font-size: 0.78rem; letter-spacing: 0.14em; text-transform: uppercase; color: var(--accent); }
        .stat-card strong { font-size: 1.85rem; line-height: 1.05; }
        .overview-panel { display: grid; gap: 32px; padding: 0 46px 40px; }
        .overview-copy h2, .gallery-section h2, .inquiry-copy h2 { font-size: clamp(2rem, 3.5vw, 2.4rem); margin-bottom: 18px; color: var(--text); }
        .overview-copy p { color: var(--text-muted); font-size: 1rem; line-height: 1.9; }
        .overview-highlights { display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 24px; }
        .spec-panel, .feature-panel { background: var(--surface); border: 1px solid var(--panel-border); border-radius: 24px; padding: 32px; }
        .spec-panel h3, .feature-panel h3 { font-size: 1.1rem; margin-bottom: 18px; color: var(--text); }
        .spec-table { width: 100%; border-collapse: collapse; }
        .spec-table th, .spec-table td { padding: 0.9rem 0; font-size: 0.96rem; color: var(--text-muted); vertical-align: top; }
        .spec-table th { width: 42%; color: var(--accent); font-weight: 600; }
        .spec-table tr:not(:last-child) td { border-bottom: 1px solid rgba(37,99,235,0.10); }
        .features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; }
        .feature-badge { padding: 14px 18px; border-radius: 999px; border: 1px solid var(--panel-border); background: var(--surface-strong); color: var(--text); font-size: 0.93rem; }
        .gallery-section { padding: 0 46px 40px; }
        .gallery-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; }
        .gallery-item { overflow: hidden; border-radius: 22px; border: 1px solid var(--panel-border); }
        .gallery-item img { width: 100%; height: 220px; object-fit: cover; transition: transform 0.35s ease; }
        .gallery-item img:hover { transform: scale(1.04); }
        .inquiry-panel { background: var(--surface); border: 1px solid var(--panel-border); border-radius: 28px; padding: 42px 46px; display: grid; gap: 26px; width: min(100%, 820px); margin: 0 auto; }
        .inquiry-copy p { color: var(--text-muted); line-height: 1.8; max-width: 760px; }
        .form-row { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
        .inquiry-panel input, .inquiry-panel textarea { width: 100%; border-radius: 16px; border: 1px solid var(--panel-border); background: #fff; color: var(--text); padding: 16px 18px; font-size: 15px; }
        .inquiry-panel textarea { min-height: 150px; resize: vertical; }
        .inquiry-panel button { width: fit-content; padding: 14px 40px; }
        @media (max-width: 1120px) { .details-hero { grid-template-columns: 1fr; } .stat-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .overview-highlights { grid-template-columns: 1fr; } }
        @media (max-width: 768px) { .details-page { padding: 60px 4% 60px; } .details-panel { border-radius: 24px; } .details-hero-copy h1 { font-size: 2.2rem; } .details-hero-media { min-height: 260px; max-height: 320px; } .gallery-item img { height: 180px; } .details-actions { grid-template-columns: 1fr; gap: 12px; } .details-actions > a { width: 100%; } .inquiry-panel { width: 100%; padding: 30px 20px; } .details-hero { gap: 18px; } .details-hero-media { min-height: 240px; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">AKAZA'S MOTORS</div>
        <ul class="nav-links">
            <li><a href="index.php#home">Home</a></li>
            <li><a href="inventory.php">Inventory</a></li>
            <li><a href="index.php#about">About</a></li>
            <li><a href="index.php#services">Services</a></li>
            <li><a href="index.php#reviews">Reviews</a></li>
            <li><a href="index.php#contact">Contact</a></li>
            <?php if (is_logged_in()): ?>
                <li><a href="my-orders.php">My Orders<?php $navCount = get_nav_order_count(); if ($navCount > 0): ?> <span style="display:inline-flex;min-width:18px;height:18px;padding:0 5px;align-items:center;justify-content:center;border-radius:999px;background:var(--accent);color:#fff;font-size:0.7rem;margin-left:4px;vertical-align:middle;"><?php echo $navCount; ?></span><?php endif; ?></a></li>
            <?php endif; ?>
            <?php if (is_admin_user()): ?>
                <li><a href="admin/dashboard.php">Admin</a></li>
            <?php endif; ?>
        </ul>
        <?php if (!empty($_SESSION['username'])): ?>
            <div class="user-area">
                <span class="user-name"><i class="fa fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a class="user-logout" href="login/logout.php"><i class="fa fa-sign-out-alt"></i> Log out</a>
            </div>
        <?php else: ?>
            <a class="nav-cta" href="login/login.php?form=signup"><i class="fa fa-user-plus"></i> Sign Up</a>
        <?php endif; ?>
    </nav>

    <?php if (!$car): ?>
        <section class="details-page">
            <div class="details-panel not-found">
                <h1>Vehicle Not Found</h1>
                <p>The vehicle you requested is unavailable or does not exist. Please return to the inventory to choose another model.</p>
                <a class="btn-white" href="inventory.php">Back to Inventory</a>
            </div>
        </section>
    <?php else: ?>
        <section class="details-page">
            <div class="details-panel">
                <div class="details-hero">
                    <div class="details-hero-copy">
                        <p class="eyebrow"><?php echo htmlspecialchars($car['tagline']); ?></p>
                        <h1><?php echo htmlspecialchars($car['name']); ?></h1>
                        <p class="subtext"><?php echo htmlspecialchars($car['year']); ?> · <?php echo htmlspecialchars($car['mileage']); ?> · <?php echo htmlspecialchars($car['status']); ?></p>
                        <div class="details-badges">
                            <span class="badge"><?php echo htmlspecialchars($car['exterior_color']); ?></span>
                            <span class="badge"><?php echo htmlspecialchars($car['interior_color']); ?></span>
                        </div>
                        
                        <div class="details-actions">
                            <a class="btn-white" href="buy-now.php?car_id=<?php echo urlencode($car['id']); ?>&id=<?php echo urlencode($car['id']); ?>">Buy Now</a>
                            <a class="btn-outline" href="#inquiry-form">Schedule Test Drive</a>
                        </div>
                    </div>
                    <div class="details-hero-media">
                        <?php $heroImage = first_car_image($car); ?>
                        <img src="<?php echo htmlspecialchars(car_image_url($heroImage)); ?>" alt="<?php echo htmlspecialchars($car['name']); ?>">
                        <div class="price-chip"><?php echo htmlspecialchars($car['price']); ?></div>
                    </div>
                </div>

                <div class="stat-grid">
                    <div class="stat-card"><span>0-60 mph</span><strong><?php echo htmlspecialchars($car['zero_to_sixty']); ?></strong></div>
                    <div class="stat-card"><span>Horsepower</span><strong><?php echo htmlspecialchars($car['horsepower']); ?></strong></div>
                    <div class="stat-card"><span>Top Speed</span><strong><?php echo htmlspecialchars($car['top_speed']); ?></strong></div>
                    <div class="stat-card"><span>Drivetrain</span><strong><?php echo htmlspecialchars($car['drivetrain']); ?></strong></div>
                </div>

                <div class="overview-panel">
                    <div class="overview-copy">
                        <h2>Overview</h2>
                        <p><?php echo htmlspecialchars($car['description']); ?></p>
                        <p><?php echo htmlspecialchars($car['description_long']); ?></p>
                    </div>
                    <div class="overview-highlights">
                        <div class="spec-panel">
                            <h3>Key Specs</h3>
                            <table class="spec-table">
                                <tr><th>Engine</th><td><?php echo htmlspecialchars($car['engine']); ?></td></tr>
                                <tr><th>Transmission</th><td><?php echo htmlspecialchars($car['transmission']); ?></td></tr>
                                <tr><th>Exterior</th><td><?php echo htmlspecialchars($car['exterior_color']); ?></td></tr>
                                <tr><th>Interior</th><td><?php echo htmlspecialchars($car['interior_color']); ?></td></tr>
                                <tr><th>Torque</th><td><?php echo htmlspecialchars($car['torque']); ?></td></tr>
                            </table>
                        </div>
                        <div class="feature-panel">
                            <h3>Luxury Features</h3>
                            <div class="features-grid">
                                <?php foreach ($car['features'] as $feature): ?>
                                    <div class="feature-badge"><?php echo htmlspecialchars($feature); ?></div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (count($car['images']) > 1): ?>
                <div class="gallery-section">
                    <h2>Gallery</h2>
                    <div class="gallery-grid">
                        <?php foreach ($car['images'] as $img): ?>
                            <div class="gallery-item"><img src="<?php echo htmlspecialchars(car_image_url($img)); ?>" alt="<?php echo htmlspecialchars($car['name']); ?>"></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="inquiry-panel" id="inquiry-form">
                    <div class="inquiry-copy">
                        <h2>Book a Test Drive</h2>
                        <p>Reserve a viewing or request more information about the <?php echo htmlspecialchars($car['name']); ?>.</p>
                    </div>
                    <form action="contact.php" method="POST">
                        <input type="hidden" name="vehicle" value="<?php echo htmlspecialchars($car['name']); ?>">
                        <div class="form-row">
                            <input type="text" name="name" placeholder="Full Name" required>
                            <input type="email" name="email" placeholder="Email Address" required>
                        </div>
                        <div class="form-row">
                            <input type="tel" name="phone" placeholder="Phone Number" required>
                            <input type="text" name="preferred_date" placeholder="Preferred Date">
                        </div>
                        <textarea name="message" placeholder="Tell us about your request..."></textarea>
                        <button type="submit" class="btn-white">Submit Inquiry</button>
                    </form>
                </div>
            </div>
        </section>
    <?php endif; ?>

</body>
</html>
